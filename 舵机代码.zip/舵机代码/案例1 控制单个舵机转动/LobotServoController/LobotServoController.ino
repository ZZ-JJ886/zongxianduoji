#include <LobotServoController.h>

LobotServoController myse;    //实例化舵机控制对象 

void setup() {
  Serial.begin(9600);
  while(!Serial);
}

void loop() {
  myse.moveServo(2,0,800); //1号舵机800ms移动至0位置
  delay(1500);
  myse.moveServo(2,1000,800); //1号舵机800ms移动至1000位置
  delay(1500);
}