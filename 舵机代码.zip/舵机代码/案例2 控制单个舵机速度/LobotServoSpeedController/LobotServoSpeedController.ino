#include <LobotServoController.h>

LobotServoController myse;  //实例化舵机控制的对象

void setup() {
  Serial.begin(9600);
  while(!Serial);

}

void loop() {
  myse.moveServo(1,0,500); //1号舵机800ms移动至0位置
  delay(1200);
  myse.moveServo(1,1000,500); //1号舵机800ms移动至1000位置
  delay(1200);
  myse.moveServo(1,0,1500); //1号舵机1200ms移动至0位置
  delay(2000);
  myse.moveServo(1,1000,1500); //1号舵机1200ms移动至1000位置
  delay(2000);
}
