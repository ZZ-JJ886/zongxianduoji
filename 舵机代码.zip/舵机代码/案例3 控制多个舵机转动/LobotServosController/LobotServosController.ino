#include <LobotServoController.h>

LobotServoController myse;    //实例化舵机控制对象

void setup() {
  Serial.begin(9600);
  while(!Serial);
}

LobotServo servos[2];   //舵机ID位置结构数组

void loop() {
  servos[0].ID = 1;       //1号舵机
  servos[0].Position = 0;  //0位置
  servos[1].ID = 2;       //2号舵机
  servos[1].Position = 0;  //0位置
  myse.moveServos(servos,2,800);  //控制两个舵机，移动时间800ms,ID和位置由servos指定
  delay(1500);
  servos[0].ID = 1;       //1号舵机
  servos[0].Position = 1000;  //1000位置
  servos[1].ID = 2;       //2号舵机
  servos[1].Position = 1000;  //1000位置
  myse.moveServos(servos,2,800);  //控制两个舵机，移动时间800ms,ID和位置由servos指定
  delay(1500);
}
