#include <LobotServoController.h>

LobotServoController myse;    //实例化舵机控制对象 

void setup() {
  Serial.begin(9600);
  while(!Serial);
}

uint8_t deviation;   //偏差
void loop() {
  myse.moveServo(1,500,500); //1号舵机500ms移动至中位
  delay(2000);
  deviation = 200;
  myse.moveServo(1,500+deviation,200); //1号舵机200ms移动至偏差位置
  while(1);
}
